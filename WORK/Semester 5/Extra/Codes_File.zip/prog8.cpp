// the program to demonstrate the simple and nested if conditions

#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
   // processing phase
   // prompt for input and read grade from user  
   cout << "Enter marks for the student: ";        
  int studentMarks;
   cin >> studentMarks; // input grade 
if ( studentMarks >= 90 ) // 90 and above gets "A"   
cout << " You have got A";
//@ make the if statements to print grades as 
// 80-89 gets "B"   

// 70-79 gets "C"   

// 60-69 gets "D"

// less than 60 gets "F"


      system("pause");
} 


// end main

