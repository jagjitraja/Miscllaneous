
#include <iostream> // allows program to output data to the screen

// function main begins program execution
int main()
{
   std::cout << "Welcome to C++!\n"; // display message

// @ display the messages - this is my first 'C++' program
// @ display the message - this program is an example of procedural programming paradigm
// @ display - Only the output statement is used for this code
// @ display - Thanks for using this code. Bye and see you soon

   return 0; // indicate that program ended successfully
} // end function main


                                                 
