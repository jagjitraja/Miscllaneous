#include <iostream>
#include <stdio.h>

using namespace std;
template <class T> T multiply(T num1, T num2); // template definition
template <class T> T divide(T num1, T num2); // template definition
/*
module11_question1.cpp: modified version of prog41.cpp
This program implements generic function to multiply and divide two numbers of any data type.
Exceptional Handling has been done.
@Author: Tanya Teotia
*/
int main ()
{
  int num1, num2, answer;
  // test by changing float to int or double.

  try{
    cout << "Please enter number 1 : ";
    cin >> num1;
    cout << "Please enter number 2 : ";
    cin >> num2;

    if(cin.fail())
        throw "Not a valid number.";

    answer = multiply(num1, num2);
    cout << "The product of " << num1 << " & " << num2 << " = " << answer << endl;
    answer = divide(num1, num2);
    cout << "The division of " << num1 << " & " << num2 << " = " << answer << endl;
  }
  catch(const char* e){
    cout << "\nError Message:" << e;
  }
  return 0;
}


template <class T> T multiply(T num1, T num2)
{

  T result = num1 * num2;
  return result;
}

template <class T> T divide(T num1, T num2)
{

  if(num2 == 0) // THROW EXCEPTION if divisor is 0
    throw "Can't divide dividend by 0. Please input another divisor.";

  T result = num1 / num2;
  return result;
}

