#include <iostream>
#include <iomanip>
#include <vector>
#include <typeinfo>
#include "Employee.h"
#include "HourlyEmployee.h"
#include "SalariedEmployee.h"
#include "CommissionEmployee.h"
#include "BasePlusCommissionEmployee.h"
using namespace std;

int main()
{
    vector < Employee * > employees( 4 );

    // initialize vector with various kinds of Employees
    employees[ 0 ] = new SalariedEmployee("Salaried", "Employee", "123-45-6789", 500 );

    employees[ 1 ] = new CommissionEmployee("Commission", "Employee","987-65-4321", 5000, 0.1 );

    employees[ 2 ] = new HourlyEmployee("Hourly", "Employee", "554-5451-5454", 126, 50 );

    employees[ 3 ] = new BasePlusCommissionEmployee("Base", "Employee", "554-65-8754", 5500, .24, 600 );

    for ( Employee *employeePtr : employees )
    {
        employeePtr->print(); // output employee information
        cout << endl;

        // get the basePlusCommission Employee to provide a raise
        BasePlusCommissionEmployee *derivedPtr = dynamic_cast < BasePlusCommissionEmployee * >( employeePtr );

        // get the Hourly Employee to provide a raise
        HourlyEmployee *derivedPtr2 = dynamic_cast < HourlyEmployee * >( employeePtr );

        // determine whether element points to a BasePlusCommissionEmployee
        if ( derivedPtr != nullptr ) {
            double oldBaseSalary = derivedPtr->getBaseSalary(); // get the old salary
            cout << "old base salary: $" << oldBaseSalary << endl; //print old salary
            derivedPtr->setBaseSalary( 1.10 * oldBaseSalary ); // provide a 10% raise
            cout << "new base salary with 10% increase is: $" << derivedPtr->getBaseSalary() << endl; // get the new salary
        } // end if


        if ( derivedPtr2 != nullptr ) {
            cout << "Old Wage: $" << derivedPtr2->getWage() << endl;
            derivedPtr2->setWage( 1.10 * derivedPtr2->getWage() );
            cout << "New Base Wage with 10% increase is: $" << derivedPtr2->getWage() << endl;
        }
        cout << "earned $" << employeePtr->earnings() << "\n------------------------------\n";

    }
}
