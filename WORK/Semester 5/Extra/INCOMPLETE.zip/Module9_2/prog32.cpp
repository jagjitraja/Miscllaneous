#include <iostream>
#include <iomanip>
#include <vector>
#include <typeinfo>
#include <ctime>
#include "Employee.h"
#include "HourlyEmployee.h"
#include "SalariedEmployee.h"
#include "CommissionEmployee.h"
#include "BasePlusCommissionEmployee.h"
using namespace std;

int main()
{
     int month;

    time_t timenow = time(0);   // getting current time in no. of seconds
    struct tm * t = localtime( &timenow ); // getting the current time using structure type of tm


    month= t->tm_mon+1; // current month

    Employee *Employees[4];  //array of Employee variable
    Employees[ 0 ] = new SalariedEmployee("John", "Smith", "111-11-1111", Date(3,11,1991), 800 );
    Employees[ 1 ] = new CommissionEmployee("Sue", "Jones","333-33-3333", Date(6,12,1994), 10000, .06 );
    Employees[ 2 ] = new HourlyEmployee("John", "Charles", "111-11-1111", Date(5,10,1995), 26, 80 );
    Employees[ 3 ] = new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444",Date(3,18,1995), 500, .4, 300 );

   for ( Employee *employeePtr : Employees ) // polymorphically process each element in array of employees
    {
        employeePtr->print(); // output all employee information
        cout << endl;

         cout << "earned $: " << employeePtr->earnings() << endl;// printing the earning of all employees

        if(month == employeePtr->getMonth()) //checking if its employee's brithday month and adding $100 in earnings
        {
             cout << "Since, its your birthday we added $100 bonus "<< endl;
             cout << "Total Earnings: " << employeePtr->earnings() + 100 << endl;
        }

        cout << "\n";
    }
}

