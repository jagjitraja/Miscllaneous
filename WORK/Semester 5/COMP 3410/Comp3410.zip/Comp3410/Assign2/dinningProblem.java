import java.util.Random;

// Author: Adarsh Jain(Addy)
// Date: 12 October 2017
public class dinningProblem {
  
// Assigining new variables
    Philosopher [] philosophers = new Philosopher[5];
    //Inilizing 5 people
    Chopstick [] chopsticks = new Chopstick[5];
    
    // Creating new thread for dinner
    Thread [] threads = new Thread[5];
    
    //Stratring a new driver
    public static void main(String[] args) 
    {
      //Creating a new instance in class
        dinningProblem dinner = new dinningProblem();
        
        dinner.startEat();

    }
   
    // This Method will start philosophers to eat from right chopstick
    //This is void mehtod becuse we cant use non static main class
    public void startEat()
    {
        System.out.println("Start");
        
        /*Initiate people and chopsticks*/
        for (int i = 0; i< 5; i++)
        {
            philosophers[i] = new Philosopher(i+1);
            chopsticks[i] = new Chopstick(i+1);
        }
       //Running First thread
        for (int i =0; i<5; i++)
        {
            final int index = i; 
            threads[i] = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                      //Thread override to start people with right chopsticks
                        philosophers[index].start(chopsticks[index],chopsticks[(index+1)%5]);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });

            threads[i].start();
        }

    }

    class Chopstick
    {
      // Each chopstick has its Id and state, which shows availability of the chopstick.
        private int cId;
        private boolean cond;

        Chopstick(int cId)
        {
            this.cId = cId;
            this.cond = true;
        }
        /*Method free makes chopstick available.*/
        public synchronized void free() throws InterruptedException
        {
            cond = true;
        }
        /*Method pick tries to pick a chopstick several times if waiting time is too long then it returns false to avoid deadlock.*/
        public synchronized boolean pick(int phId) throws InterruptedException{
            int count = 0;
         /*wait variable to avoid deadlock*/
            int wait = new Random().nextInt(10) + 5;
            while (!cond)
            {
              /*wait for chopstick*/
                Thread.sleep(new Random().nextInt(100) + 50);
                count++;
                if(count > wait)
                {
                    return false;
                }
            }
            /*make chopstick unavalible*/
            cond = false;
            return true;
        }
    }
    class Philosopher extends Thread
    {
      /* Philosopher has an Id, left and right chopstick. */
        private int phId;
        private Chopstick left, right;

        public Philosopher(int phId)
        {
            this.phId = phId;
        }


        /* Method eat tries to pick up chopsticks if they are unavailable it does nothing.If chopsticks are availible, thread will sleep for a period of time and release chopsticks afterwards.*/
        public void eat() throws InterruptedException
        {
            boolean rightf, leftf = false;

            System.out.println("The Philosopher: " + phId + " is alot hungry");
            System.out.println("The Philosopher: " + phId + " tries to pick left chopstick");
            leftf = left.pick(phId);
            /*if left chopstick is not availible - stop eat()*/
            if(!leftf)
            {
                return;
            }
            System.out.println("The Philosopher: " + phId + " tries to pick right chopstick");
            rightf = right.pick(phId);
            /*if right chopstick is not availible - stop eat()*/
            if(!rightf)
            {
                return;
            }
            System.out.println("The Philosopher: " + phId + " start eating");
            /*Eat for random time*/
            Thread.sleep(new Random().nextInt(1000) + 200);
            /*make chopsticks availible*/
            left.free();
            right.free();

            System.out.println("The Philosopher: " + phId + " end eating");

        }
        /* Method think makes philosopher wait for a random time.*/
        public void think() throws InterruptedException
        {
            System.out.println("The Philosopher: " + phId + " thinking");
            Thread.sleep(new Random().nextInt(500) + 100);
            System.out.println("The Philosopher: " + phId + " stops thinking");
        }
        /* Method start randomly starts method eat or think.*/
        public void start(Chopstick left, Chopstick right) throws InterruptedException
        {
            this.left = left;
            this.right = right;
            while(true)
            {
              /*randomly start eating or thinking*/
                if (new Random().nextBoolean())
                {
                    eat();
                }else
                {
                    think();
                }
            }
        }
    }

}
