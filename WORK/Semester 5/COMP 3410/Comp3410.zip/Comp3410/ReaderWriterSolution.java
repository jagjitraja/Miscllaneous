/**
 * Original code by Silberschatz, Galvin, and Gagne
 * from Operating System Concepts with Java, 7th Edition
 * Modified by William McDaniel Albritton
 *
 * ReaderWriterSolution.java
 *
 * This class creates the reader and writer threads and
 * the database they will be using to coordinate access.
 */

   import java.util.concurrent.Semaphore;

    public class ReaderWriterSolution{
      public static final int NUM_OF_READERS = 4;
      public static final int NUM_OF_WRITERS = 2;
   
       public static void main(String args[]){
         RWLock database = new Database();
      
         Thread[] readerArray = new Thread[NUM_OF_READERS];
         Thread[] writerArray = new Thread[NUM_OF_WRITERS];
         
      
         for (int i = 0; i < NUM_OF_READERS; i++) {
            readerArray[i] = new Thread(new Reader(i, database));
            readerArray[i].start();
         }
      
         for (int i = 0; i < NUM_OF_WRITERS; i++) {
            writerArray[i] = new Thread(new Writer(i, database));
            writerArray[i].start();
         }
      }
   }

//****************************************************************

/**
 * An interface for reader-writer locks.
 *
 * In the text we do not have readers and writers
 * pass their number into each method. However we do so
 * here to aid in output messages.
 */

    interface RWLock{
       public abstract void acquireReadLock(int readerNum);
       public abstract void acquireWriteLock(int writerNum);
       public abstract void releaseReadLock(int readerNum);
       public abstract void releaseWriteLock(int writerNum);
   }

//****************************************************************

/**
 * Database.java
 *
 * This class contains the methods the readers and writers will use
 * to coordinate access to the database. Access is coordinated using semaphores.
 */


    class Database implements RWLock{
      private int readerCount;  // the number of active readers
      private Semaphore mutex;  // controls access to readerCount
      private Semaphore db;     // controls access to the database
   
       public Database() {
         readerCount = 0;
         mutex = new Semaphore(1);   // This is mutual exclusion to change the value of readercount
         db = new Semaphore(1);      // this is database lock -> first reader will lock database and last reader will release this
                                     //each writer will lock and release
         
      }
   
       public void acquireReadLock(int readerNum) {
         try{
         //mutual exclusion for readerCount 
            mutex.acquire();
         }
             catch (InterruptedException e) {}
      
         ++readerCount;
      
      // if I am the first reader tell all others
      // that the database is being read
         if (readerCount == 1){
            try{
               db.acquire();
               System.out.println("I am the first reader " + readerNum + ", so I acquired the lock!");
            }
                catch (InterruptedException e) {}
         }
      
         //System.out.println("Reader " + readerNum + " is reading. Reader count = " + readerCount);
         //mutual exclusion for readerCount
         mutex.release();
      }
   
       public void releaseReadLock(int readerNum) {
         try{
         //mutual exclusion for readerCount
            mutex.acquire();
         }
             catch (InterruptedException e) {}
      
         --readerCount;
      
      // if I am the last reader tell all others
      // that the database is no longer being read
         if (readerCount == 0){
           System.out.println("I am the last reader, so I am releasing the lock");
            db.release();
         }
      
         //System.out.println("Reader " + readerNum + " is done reading. Reader count = " + readerCount);
      
      //mutual exclusion for readerCount
         mutex.release();
      }
   
       public void acquireWriteLock(int writerNum) {
         try{
            db.acquire();
         }
             catch (InterruptedException e) {}
         System.out.println("I Am the writer " + writerNum + ", and am writing ");
      }
   
       public void releaseWriteLock(int writerNum) {
         System.out.println("I am done writing.");
         db.release();
      }
   
   
   }

//***********************************************************

/**
 * Reader.java
 *
 * A reader to the database.
 *
 */

    class Reader implements Runnable
   {
   
      private RWLock database;
      private int readerNum;
   
       public Reader(int readerNum, RWLock database) {
         this.readerNum = readerNum;
         this.database = database;
      }
   
       public void run() {
         while (true) {

           try {
             Thread.sleep(2000); } catch(Exception e) {};
            System.out.println("reader " + readerNum + " wants to read.");
            database.acquireReadLock(readerNum);
         
            try {
             Thread.sleep(2000); } catch(Exception e) {};
         
            database.releaseReadLock(readerNum);
         }
      }
   ;
   }

//**************************************************************

/**
 * Writer.java
 *
 * A writer to the database.
 *
 */
    class Writer implements Runnable
   {
      private RWLock database;
      private int writerNum;
   
       public Writer(int w, RWLock d) {
         writerNum = w;
         database = d;
      }
   
       public void run() {
         while (true){

           try {
             Thread.sleep(2000); } 
           catch(Exception e) {};
         
            System.out.println("writer " + writerNum + " wants to write.");
            database.acquireWriteLock(writerNum);
         
     
  try {
             Thread.sleep(2000); } catch(Exception e) {};
         
            database.releaseWriteLock(writerNum);
         }
      }
   
   
   }

