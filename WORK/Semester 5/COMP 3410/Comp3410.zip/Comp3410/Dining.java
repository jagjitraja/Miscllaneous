import java.util.*;

public class Dining implements Runnable
{
  public Object leftChopstick, rightChopstick;
  
  public Dining()
  {
    this.leftChopstick = false;
    this.leftChopstick = false;
  }
  
  public void start()
  {
    takeRight();
    takeLeft();
    try()
    {
      eat();
    } catch (InterruptedException)
    {
      Thread.currentThread().Interrupt
    }
    putRight();
    putLeft();
  }
  
  public synchronized void takeRight()
  {
    while()
    {
      
    }
    takeRight = true;
    System.out.println(Thread.currentThread().getName()
                         +" This is the right chopstick");
  }
  
  public synchronized void takeLeft()
  {
    while()
    {
      
    }
    takeLeft = true;
    System.out.println(Thread.currentThread().getName()
                         +" This is the left chopstick");
  }
  
  public synchronized void putRight()
  {
    while(putRight)
    {
      
    }
    takeRight = true;
    System.out.println(Thread.currentThread().getName()
                         +" This is the right chopstick");
  }
  public synchronized void putLeft()
  {
    while(putleft)
    {
      
    }
    takeRight = true;
    System.out.println(Thread.currentThread().getName()
                         +" This is the right chopstick");
  }