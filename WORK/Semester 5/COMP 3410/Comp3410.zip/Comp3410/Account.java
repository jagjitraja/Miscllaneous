public class Account {
  private float balance;
  private float rate;
  public int acctNumber;
  
  public Account(float b, float r, int num)
  {
    balance = b;
    rate = r;
    acctNumber = num;
  }
  
  public synchronized void deposit(float amount) 
  {
    balance += amount;
    System.out.println("Account " + acctNumber+ " deposited :"+ amount + "Balance is :"+ balance);
  }
  
  public synchronized void withdraw (float amount) 
  {
    if (balance < amount)
    {
      System.out.println("Account "+acctNumber+" overdrawn! ");
      balance = 0;
    }
    else 
    {
      balance -=amount;
      System.out.println("Account "+acctNumber+ " deposited :"+ amount + "Balance is :"+ balance);
    }
  }
}