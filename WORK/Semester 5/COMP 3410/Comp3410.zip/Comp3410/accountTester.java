import java.util.Random;
public class accountTester
{
  public static void main(String[] args)
  {
    float a = 2000.0f;
    float b = 1250.0f;
    int c = 1001;
    final Account act = new Account(a,b,c);
    Thread prod = new Thread(new Runnable()
    {
      public void run()
      {
        Random r = new Random();
        for(int i=0; i<10; i++)
        {
          Float f = (float) r.nextInt(100-2)+2;
          act.deposit(f);
        }
      }
    });
    
    Thread cons = new Thread(new Runnable()
    {
      public void run()
      {
        float x=120.0f;
        for (int i=0; i<10; i++)
        {
          act.withdraw(x);
        }
      }
    });
    
    prod.start();
    cons.start();
    try
    {
      prod.join();
      cons.join();
    }
    catch(InterruptedException e)
    {
      return;
    }
  }
}